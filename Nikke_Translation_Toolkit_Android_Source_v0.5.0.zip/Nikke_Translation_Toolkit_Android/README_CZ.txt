NIKKE Translation Toolkit – Android (0.5.0)
============================================

Co verze 0.3.0 umí:
- vybrat store.cdb.idx a store.cdb přes Android systémový výběr souborů,
- načíst CIDX bez načtení celého CDB do RAM,
- projít obsah každého CIDX bloku streamingově,
- hledat case-insensitive výskyty Locale_, Localization, Message a TextAsset,
- hledat ASCII i UTF-16LE varianty,
- u každého kandidáta uložit index, offset, velikost, hash, první pozici shody,
  detekované klíče, kódování a krátký náhled okolních dat,
- exportovat nikke_localization_candidates.json,
- exportovat nikke_localization_candidates.csv,
- navíc exportovat nalezené bloky do 32 MB pro další analýzu.

Použití:
1. Spusť aplikaci.
2. Vyber store.cdb.idx.
3. Vyber odpovídající store.cdb.
4. Klepni na „Najít lokalizační kandidáty“.
5. Po dokončení klepni na „Exportovat JSON + CSV + malé bloky“.
6. Vyber cílovou složku, např. Download/NIKKE_SCAN.

Poznámka:
Sken 4GB CDB může na telefonu trvat déle. Program data čte po blocích a nepokouší se
načíst celý store.cdb do operační paměti.


VERZE 0.3.0 – FONTY
- hledání TTF/OTF/WOFF/WOFF2/TTC podpisů
- hledání TMP_FontAsset, FontAsset, FontData, .ttf a .otf v ASCII i UTF-16LE
- validované TTF/OTF/WOFF fonty se automaticky vyříznou do složky nikke_fonts
- nikke_font_candidates.json a nikke_font_candidates.csv obsahují bloky s fontovými odkazy
- TMP_FontAsset kandidáty se exportují jako bloky/report; Unity serializované fontové assety mohou vyžadovat další rozbalení AssetBundle.


VERZE 0.4.0
- Po dokončení skenu zobrazuje lokalizační kandidáty přímo v aplikaci.
- Filtr: Vše / Locale_ / Localization / Message / TextAsset.
- Kliknutím na kandidáta se otevře detail bloku, offset, hash a textový náhled.
- Tlačítka Otevřít JSON a Otevřít CSV zobrazí report přímo v aplikaci i před exportem.
- Export JSON/CSV a fontů z verze 0.3 zůstává zachovaný.

VERZE 0.5.0 – HLOUBKOVÝ SKEN UNITYFS / LZ4 / LZMA
- před druhým hledáním rozpozná UnityFS, LZ4 frame a LZMA-alone obaly,
- UnityFS načte block-info a podporuje interní bloky bez komprese, LZ4, LZ4HC a LZMA,
- po rozbalení znovu hledá Locale_, Localization, Message a TextAsset v ASCII i UTF-16LE,
- hledá tyto výrazy také v názvech virtuálních souborů uvnitř UnityFS,
- pokud blok začíná NKAB a stávající NKAB decryptor jej umí dešifrovat, pokusí se na výsledku spustit stejný UnityFS/LZ4/LZMA sken,
- report uvádí počet rozpoznaných kontejnerů a úspěšně rozbalených vrstev,
- JSON/CSV nově obsahují také layer a detail, aby bylo vidět, zda shoda pochází z RAW CDB nebo z rozbaleného UnityFS/LZ4/LZMA,
- ochranný limit: jedna CDB položka max. 64 MB pro hluboké rozbalení a max. 256 MB rozbalených dat na vrstvu, aby aplikace nezaplnila RAM telefonu.

Poznámka: tato verze rozbaluje kontejner a kompresi, ale ještě neparsuje samotné Unity SerializedFile objekty na typy MonoBehaviour/TextAsset. Pokud budou texty uvnitř serializovaných objektů bez čitelných markerů, další krok je parser Unity SerializedFile/TypeTree.
