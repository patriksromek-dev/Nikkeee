package online.hrycesky.nikketoolkit;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import android.os.ParcelFileDescriptor;
import java.io.*;
import java.nio.*;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final int PICK_IDX=1001, PICK_CDB=1002, PICK_EXPORT_TREE=2001;
    private Uri idxUri, cdbUri;
    private TextView status, idxLabel, cdbLabel;
    private ProgressBar progress;
    private Button scanButton, exportButton, openJsonButton, openCsvButton;
    private Spinner filterSpinner;
    private LinearLayout candidateList;
    private TextView candidateHeader;
    private final List<Candidate> candidates=new ArrayList<>();
    private final List<FontCandidate> fontCandidates=new ArrayList<>();

    static final class FontCandidate {
        CidxParser.Entry e;
        String kind;
        FontScanner.Result result;
        FontCandidate(CidxParser.Entry e,String kind,FontScanner.Result result){this.e=e;this.kind=kind;this.result=result;}
    }

    static final class Candidate {
        CidxParser.Entry e;
        String kind;
        String layer;
        String detail;
        LinkedHashSet<String> matches;
        long matchOffset;
        String encoding;
        String preview;
        Candidate(CidxParser.Entry e,String kind,LocalizationScanner.Result r){
            this(e,kind,"RAW CDB","",r);
        }
        Candidate(CidxParser.Entry e,String kind,String layer,String detail,LocalizationScanner.Result r){
            this.e=e; this.kind=kind; this.layer=layer; this.detail=detail; this.matches=new LinkedHashSet<>(r.terms);
            this.matchOffset=r.firstMatchRelativeOffset; this.encoding=r.encoding; this.preview=r.preview;
        }
    }

    @Override public void onCreate(Bundle b){ super.onCreate(b); setContentView(makeUi()); }

    private View makeUi(){
        ScrollView sv=new ScrollView(this);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(28,28,28,28); box.setBackgroundColor(Color.rgb(245,245,245));
        box.addView(t("NIKKE Translation Toolkit",26,true));
        TextView sub=t("Prohledá store.cdb, automaticky rozbalí podporované UnityFS bloky (LZ4/LZ4HC/LZMA) a znovu v rozbalených datech hledá Locale_, Localization, Message a TextAsset. Současně zachovává sken fontů.",15,false); sub.setPadding(0,8,0,18); box.addView(sub);

        Button pickIdx=btn("Vybrat store.cdb.idx"); pickIdx.setOnClickListener(v->pick(PICK_IDX)); box.addView(pickIdx);
        idxLabel=t("IDX: nevybrán",13,false); box.addView(idxLabel);
        Button pickCdb=btn("Vybrat store.cdb"); pickCdb.setOnClickListener(v->pick(PICK_CDB)); box.addView(pickCdb);
        cdbLabel=t("CDB: nevybrán",13,false); box.addView(cdbLabel);

        scanButton=btn("Najít texty + fonty"); scanButton.setEnabled(false); scanButton.setOnClickListener(v->scan()); box.addView(scanButton);
        exportButton=btn("Exportovat texty + fonty"); exportButton.setEnabled(false); exportButton.setOnClickListener(v->exportCandidates()); box.addView(exportButton);

        LinearLayout reportButtons=new LinearLayout(this); reportButtons.setOrientation(LinearLayout.HORIZONTAL);
        openJsonButton=btn("Otevřít JSON"); openJsonButton.setEnabled(false); openJsonButton.setOnClickListener(v->showReport("JSON", buildLocalizationJson()));
        openCsvButton=btn("Otevřít CSV"); openCsvButton.setEnabled(false); openCsvButton.setOnClickListener(v->showReport("CSV", buildLocalizationCsv()));
        reportButtons.addView(openJsonButton,new LinearLayout.LayoutParams(0,-2,1));
        reportButtons.addView(openCsvButton,new LinearLayout.LayoutParams(0,-2,1));
        box.addView(reportButtons);

        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); progress.setMax(1000); progress.setVisibility(View.GONE); box.addView(progress,new LinearLayout.LayoutParams(-1,24));
        status=t("Vyber oba soubory. Sken probíhá přímo nad CDB a celý 4GB soubor se nenačítá do RAM.",14,false); status.setTextIsSelectable(true); status.setPadding(0,18,0,22); box.addView(status);

        candidateHeader=t("Nalezení kandidáti",20,true); candidateHeader.setVisibility(View.GONE); candidateHeader.setPadding(0,12,0,8); box.addView(candidateHeader);
        filterSpinner=new Spinner(this);
        ArrayAdapter<String> filterAdapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,new String[]{"Vše","Locale_","Localization","Message","TextAsset"});
        filterAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); filterSpinner.setAdapter(filterAdapter); filterSpinner.setVisibility(View.GONE);
        filterSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onItemSelected(android.widget.AdapterView<?> parent,View view,int position,long id){ renderCandidates(position==0?"":String.valueOf(parent.getItemAtPosition(position))); }
            public void onNothingSelected(android.widget.AdapterView<?> parent){}
        });
        box.addView(filterSpinner);
        candidateList=new LinearLayout(this); candidateList.setOrientation(LinearLayout.VERTICAL); candidateList.setVisibility(View.GONE); box.addView(candidateList);
        sv.addView(box); return sv;
    }

    private TextView t(String s,int sp,boolean bold){ TextView v=new TextView(this); v.setText(s); v.setTextSize(sp); v.setTextColor(Color.rgb(25,25,25)); if(bold)v.setTypeface(null,1); return v; }
    private Button btn(String s){ Button b=new Button(this); b.setText(s); return b; }
    private void pick(int req){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*"); startActivityForResult(i,req); }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode!=RESULT_OK||data==null)return;
        Uri u=data.getData(); if(u==null)return;
        try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);}catch(Exception ignored){}
        if(requestCode==PICK_IDX){idxUri=u;idxLabel.setText("IDX: "+u);}
        else if(requestCode==PICK_CDB){cdbUri=u;cdbLabel.setText("CDB: "+u);}
        else if(requestCode==PICK_EXPORT_TREE){doExport(u);return;}
        scanButton.setEnabled(idxUri!=null&&cdbUri!=null);
    }

    private void scan(){
        scanButton.setEnabled(false); exportButton.setEnabled(false); openJsonButton.setEnabled(false); openCsvButton.setEnabled(false); progress.setVisibility(View.VISIBLE); progress.setProgress(0);
        status.setText("Načítám CIDX. Nejprve hledám přímo v blocích, potom rozbaluji UnityFS / LZ4 / LZMA a znovu hledám lokalizace…"); candidates.clear(); fontCandidates.clear();
        candidateHeader.setVisibility(View.GONE); filterSpinner.setVisibility(View.GONE); candidateList.removeAllViews(); candidateList.setVisibility(View.GONE);
        new Thread(()->{
            try(ParcelFileDescriptor pIdx=getContentResolver().openFileDescriptor(idxUri,"r"); ParcelFileDescriptor pCdb=getContentResolver().openFileDescriptor(cdbUri,"r")){
                if(pIdx==null||pCdb==null) throw new IOException("Soubor nelze otevřít.");
                FileChannel idxCh=new FileInputStream(pIdx.getFileDescriptor()).getChannel();
                FileChannel cdbCh=new FileInputStream(pCdb.getFileDescriptor()).getChannel();
                List<CidxParser.Entry> entries=CidxParser.parse(idxCh);
                long cdbSize=cdbCh.size();
                int invalid=0, scanned=0, deepDetected=0, deepPayloads=0;
                Map<String,Integer> termCounts=new LinkedHashMap<>();
                termCounts.put("Locale_",0); termCounts.put("Localization",0); termCounts.put("Message",0); termCounts.put("TextAsset",0);

                for(int i=0;i<entries.size();i++){
                    CidxParser.Entry e=entries.get(i);
                    if(e.offset<0||e.size<=0||e.offset>cdbSize||e.size>cdbSize-e.offset){ invalid++; continue; }
                    LocalizationScanner.Result r=LocalizationScanner.scan(cdbCh,e.offset,e.size);
                    FontScanner.Result fr=FontScanner.scan(cdbCh,e.offset,e.size);
                    scanned++;
                    byte[] head=readHead(cdbCh,e.offset,e.size,64);
                    String kind=magic(head);
                    if(r.found()){
                        candidates.add(new Candidate(e,kind,r));
                        for(String term:r.terms) termCounts.put(term,termCounts.get(term)+1);
                    }
                    if(fr.found()) fontCandidates.add(new FontCandidate(e,kind,fr));

                    // Deep pass: only entries with a recognizable container/compression header are loaded into RAM.
                    if(DeepContainerScanner.likelyContainer(head)){
                        deepDetected++;
                        List<DeepContainerScanner.Payload> payloads=DeepContainerScanner.unpack(cdbCh,e.offset,e.size);
                        deepPayloads += payloads.size();
                        for(DeepContainerScanner.Payload payload:payloads){
                            LocalizationScanner.Result dr=LocalizationScanner.scan(payload.data);
                            LocalizationScanner.Result pr=LocalizationScanner.scanPaths(payload.paths);
                            LocalizationScanner.Result merged=mergeResults(dr,pr);
                            if(merged.found()){
                                candidates.add(new Candidate(e,kind,payload.layer,payload.detail,merged));
                                for(String term:merged.terms) termCounts.put(term,termCounts.get(term)+1);
                            }
                        }
                    }
                    if(i%50==0){
                        final int pp=(int)((i*1000L)/Math.max(1,entries.size()));
                        final int ci=candidates.size(), fi=fontCandidates.size();
                        runOnUiThread(()->{ progress.setProgress(pp); status.setText("Skenuji + rozbaluji bloky… "+pp/10.0+" %\nLokalizační kandidáti: "+ci+"\nFontové kandidáty: "+fi); });
                    }
                }

                StringBuilder report=new StringBuilder();
                report.append("Sken dokončen.\n\n");
                report.append("CIDX záznamů: ").append(entries.size()).append("\n");
                report.append("Prohledaných bloků: ").append(scanned).append("\n");
                report.append("CDB velikost: ").append(human(cdbSize)).append("\n");
                report.append("Neplatné záznamy: ").append(invalid).append("\n");
                report.append("Rozpoznaných komprimovaných/kontejnerových bloků: ").append(deepDetected).append("\n");
                report.append("Úspěšně rozbalených vrstev: ").append(deepPayloads).append("\n\n");
                report.append("Lokalizačních kandidátů: ").append(candidates.size()).append("\n");
                report.append("Fontových kandidátů: ").append(fontCandidates.size()).append("\n");
                int embeddedFontCount=0; for(FontCandidate fc:fontCandidates) embeddedFontCount+=fc.result.embeddedFonts.size();
                report.append("Přímo vyříznutelných TTF/OTF/WOFF fontů: ").append(embeddedFontCount).append("\n");
                for(Map.Entry<String,Integer> x:termCounts.entrySet()) report.append(x.getKey()).append(": ").append(x.getValue()).append(" bloků\n");
                report.append("\n");
                int lim=Math.min(100,candidates.size());
                for(int i=0;i<lim;i++){
                    Candidate c=candidates.get(i);
                    report.append(String.format(Locale.US,"#%d  %s→%s  off=%d  size=%s  match@+%d  [%s]\n",c.e.index,c.kind,c.layer,c.e.offset,human(c.e.size),c.matchOffset,join(c.matches," | ")));
                    if(!c.preview.isEmpty()) report.append("  ").append(shorten(c.preview,180)).append("\n");
                }
                if(candidates.size()>lim) report.append("… další kandidáti budou v JSON/CSV exportu.\n");
                final String out=report.toString();
                runOnUiThread(()->{
                    status.setText(out); progress.setProgress(1000); progress.setVisibility(View.GONE); scanButton.setEnabled(true);
                    boolean hasAny=!candidates.isEmpty() || !fontCandidates.isEmpty();
                    exportButton.setEnabled(hasAny); openJsonButton.setEnabled(!candidates.isEmpty()); openCsvButton.setEnabled(!candidates.isEmpty());
                    candidateHeader.setVisibility(candidates.isEmpty()?View.GONE:View.VISIBLE);
                    filterSpinner.setVisibility(candidates.isEmpty()?View.GONE:View.VISIBLE);
                    candidateList.setVisibility(candidates.isEmpty()?View.GONE:View.VISIBLE);
                    if(!candidates.isEmpty()){ filterSpinner.setSelection(0); renderCandidates(""); }
                });
            }catch(Exception ex){runOnUiThread(()->{status.setText("Chyba: "+ex);progress.setVisibility(View.GONE);scanButton.setEnabled(true);});}
        }).start();
    }

    private LocalizationScanner.Result mergeResults(LocalizationScanner.Result a,LocalizationScanner.Result b){
        LocalizationScanner.Result r=new LocalizationScanner.Result();
        r.terms.addAll(a.terms); r.terms.addAll(b.terms);
        if(a.found()){ r.firstMatchRelativeOffset=a.firstMatchRelativeOffset; r.encoding=a.encoding; r.preview=a.preview; }
        if(b.found()){
            if(!a.found()){ r.firstMatchRelativeOffset=b.firstMatchRelativeOffset; r.encoding=b.encoding; r.preview=b.preview; }
            else if(b.preview!=null&&!b.preview.isEmpty()){
                r.preview=(r.preview==null||r.preview.isEmpty()?"":r.preview+" | UnityFS path: ")+b.preview;
                if(r.encoding==null||r.encoding.isEmpty()) r.encoding=b.encoding; else r.encoding=r.encoding+" + "+b.encoding;
            }
        }
        return r;
    }

    private byte[] readHead(FileChannel ch,long off,long size,int max)throws IOException{
        int want=(int)Math.min((long)max,size); ByteBuffer b=ByteBuffer.allocate(want); int got=0;
        while(b.hasRemaining()){int r=ch.read(b,off+got); if(r<0)break; if(r==0)break; got+=r;}
        byte[] out=new byte[got]; b.flip(); b.get(out); return out;
    }

    private String magic(byte[] b){
        if(starts(b,"NKAB")) return "NKAB"; if(starts(b,"NKDB"))return "NKDB"; if(starts(b,"UnityFS"))return "UnityFS";
        if(b.length>=4&&b[0]=='P'&&b[1]=='K'&&(b[2]==3||b[2]==5||b[2]==7))return "ZIP"; return "DATA";
    }
    private boolean starts(byte[] b,String s){byte[] x=s.getBytes(StandardCharsets.US_ASCII); if(b.length<x.length)return false; for(int i=0;i<x.length;i++)if(b[i]!=x[i])return false; return true;}

    private void renderCandidates(String filter){
        if(candidateList==null)return;
        candidateList.removeAllViews();
        int shown=0,total=0;
        for(Candidate c:candidates){
            if(filter!=null&&!filter.isEmpty()&&!c.matches.contains(filter))continue;
            total++;
            if(shown>=500)continue;
            LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(18,14,18,14);
            GradientDrawable bg=new GradientDrawable(); bg.setColor(Color.WHITE); bg.setCornerRadius(14f); bg.setStroke(1,Color.rgb(210,210,210)); card.setBackground(bg);
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.setMargins(0,7,0,7);
            TextView title=t("#"+c.e.index+"  "+c.kind+" → "+c.layer+"  ["+join(c.matches," | ")+"]",15,true); card.addView(title);
            TextView meta=t("offset="+c.e.offset+"   size="+human(c.e.size)+"   match@+"+c.matchOffset+"   "+c.encoding,12,false); meta.setTextColor(Color.DKGRAY); card.addView(meta);
            if(c.preview!=null&&!c.preview.isEmpty()){
                TextView pv=t(shorten(c.preview,420),13,false); pv.setTextIsSelectable(true); pv.setPadding(0,8,0,0); card.addView(pv);
            }
            final Candidate selected=c;
            card.setOnClickListener(v->showCandidateDetail(selected));
            candidateList.addView(card,cp); shown++;
        }
        candidateHeader.setText("Nalezení kandidáti: "+total+(shown<total?" (zobrazeno prvních "+shown+")":""));
        if(total==0){ TextView none=t("Pro tento filtr nebyl nalezen žádný kandidát.",14,false); none.setPadding(0,14,0,14); candidateList.addView(none); }
    }

    private void showCandidateDetail(Candidate c){
        String text="Blok #"+c.e.index+"\nTyp: "+c.kind+"\nVrstva: "+c.layer+"\nDetail rozbalení: "+c.detail+"\nKlíče: "+join(c.matches," | ")+"\nOffset CDB: "+c.e.offset+"\nVelikost bloku: "+c.e.size+"\nHash: "+c.e.hashHex()+"\nShoda v prohledávané vrstvě @ +"+c.matchOffset+"\nKódování: "+c.encoding+"\n\nNáhled:\n"+c.preview;
        showTextDialog("Kandidát #"+c.e.index,text);
    }

    private void showReport(String type,String content){ showTextDialog("NIKKE – "+type,content); }

    private void showTextDialog(String title,String content){
        TextView tv=t(content,12,false); tv.setTextIsSelectable(true); tv.setPadding(24,18,24,18); tv.setTypeface(android.graphics.Typeface.MONOSPACE);
        ScrollView scroll=new ScrollView(this); scroll.addView(tv);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(title).setView(scroll).setPositiveButton("Zavřít",null).create();
        dialog.setOnShowListener(d->{ Window w=dialog.getWindow(); if(w!=null)w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT); });
        dialog.show();
    }

    private String buildLocalizationCsv(){
        StringBuilder csv=new StringBuilder("index,kind,layer,detail,offset,size,hash,match_relative_offset,encoding,matches,preview\n");
        for(Candidate c:candidates){
            csv.append(c.e.index).append(',').append(csvQ(c.kind)).append(',').append(csvQ(c.layer)).append(',').append(csvQ(c.detail)).append(',').append(c.e.offset).append(',').append(c.e.size).append(',')
                    .append(c.e.hashHex()).append(',').append(c.matchOffset).append(',')
                    .append(csvQ(c.encoding)).append(',').append(csvQ(join(c.matches,"|"))).append(',').append(csvQ(c.preview)).append('\n');
        }
        return csv.toString();
    }

    private String buildLocalizationJson(){
        StringBuilder json=new StringBuilder();
        json.append("{\n  \"format\": \"NIKKE localization candidate scan\",\n  \"keywords\": [\"Locale_\", \"Localization\", \"Message\", \"TextAsset\"],\n  \"candidate_count\": ").append(candidates.size()).append(",\n  \"candidates\": [\n");
        for(int i=0;i<candidates.size();i++){
            Candidate c=candidates.get(i);
            json.append("    {\n")
                    .append("      \"index\": ").append(c.e.index).append(",\n")
                    .append("      \"kind\": \"").append(jsonEscape(c.kind)).append("\",\n")
                    .append("      \"layer\": \"").append(jsonEscape(c.layer)).append("\",\n")
                    .append("      \"detail\": \"").append(jsonEscape(c.detail)).append("\",\n")
                    .append("      \"offset\": ").append(c.e.offset).append(",\n")
                    .append("      \"size\": ").append(c.e.size).append(",\n")
                    .append("      \"hash\": \"").append(c.e.hashHex()).append("\",\n")
                    .append("      \"match_relative_offset\": ").append(c.matchOffset).append(",\n")
                                        .append("      \"match_absolute_offset\": ");
            if("RAW CDB".equals(c.layer) && c.matchOffset>=0) json.append(c.e.offset+c.matchOffset); else json.append("null");
            json.append(",\n")
                    .append("      \"encoding\": \"").append(jsonEscape(c.encoding)).append("\",\n")
                    .append("      \"matches\": [");
            int mi=0; for(String m:c.matches){if(mi++>0)json.append(", "); json.append('"').append(jsonEscape(m)).append('"');}
            json.append("],\n      \"preview\": \"").append(jsonEscape(c.preview)).append("\"\n    }");
            if(i+1<candidates.size())json.append(','); json.append('\n');
        }
        json.append("  ]\n}\n"); return json.toString();
    }

    private void exportCandidates(){ if(candidates.isEmpty() && fontCandidates.isEmpty())return; Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE); startActivityForResult(i,PICK_EXPORT_TREE); }

    private void doExport(Uri tree){
        status.append("\n\nExportuji lokalizaci, fontové reporty a nalezené fonty…"); exportButton.setEnabled(false);
        new Thread(()->{
            int blobs=0, failed=0;
            StringBuilder csv=new StringBuilder("index,kind,layer,detail,offset,size,hash,match_relative_offset,encoding,matches,preview\n");
            StringBuilder json=new StringBuilder();
            json.append("{\n  \"format\": \"NIKKE localization candidate scan\",\n  \"keywords\": [\"Locale_\", \"Localization\", \"Message\", \"TextAsset\"],\n  \"candidate_count\": ").append(candidates.size()).append(",\n  \"candidates\": [\n");

            try(ParcelFileDescriptor pCdb=getContentResolver().openFileDescriptor(cdbUri,"r")){
                if(pCdb==null)throw new IOException("CDB nelze otevřít");
                FileChannel ch=new FileInputStream(pCdb.getFileDescriptor()).getChannel();
                for(int i=0;i<candidates.size();i++){
                    Candidate c=candidates.get(i);
                    String matches=join(c.matches,"|");
                    csv.append(c.e.index).append(',').append(csvQ(c.kind)).append(',').append(csvQ(c.layer)).append(',').append(csvQ(c.detail)).append(',')
                            .append(c.e.offset).append(',').append(c.e.size).append(',').append(c.e.hashHex()).append(',').append(c.matchOffset).append(',')
                            .append(csvQ(c.encoding)).append(',').append(csvQ(matches)).append(',').append(csvQ(c.preview)).append('\n');

                    json.append("    {\n")
                            .append("      \"index\": ").append(c.e.index).append(",\n")
                            .append("      \"kind\": \"").append(jsonEscape(c.kind)).append("\",\n")
                            .append("      \"layer\": \"").append(jsonEscape(c.layer)).append("\",\n")
                            .append("      \"detail\": \"").append(jsonEscape(c.detail)).append("\",\n")
                            .append("      \"offset\": ").append(c.e.offset).append(",\n")
                            .append("      \"size\": ").append(c.e.size).append(",\n")
                            .append("      \"hash\": \"").append(c.e.hashHex()).append("\",\n")
                            .append("      \"match_relative_offset\": ").append(c.matchOffset).append(",\n")
                                                        .append("      \"match_absolute_offset\": ");
                    if("RAW CDB".equals(c.layer) && c.matchOffset>=0) json.append(c.e.offset+c.matchOffset); else json.append("null");
                    json.append(",\n")
                            .append("      \"encoding\": \"").append(jsonEscape(c.encoding)).append("\",\n")
                            .append("      \"matches\": [");
                    int mi=0; for(String m:c.matches){ if(mi++>0)json.append(", "); json.append("\"").append(jsonEscape(m)).append("\""); }
                    json.append("],\n      \"preview\": \"").append(jsonEscape(c.preview)).append("\"\n    }");
                    if(i+1<candidates.size()) json.append(','); json.append('\n');

                    // Keep original convenience export, but avoid filling phone storage.
                    if(c.e.size<=32L*1024*1024){
                        try{
                            String ext=".bin"; if("NKAB".equals(c.kind))ext=".nkab"; else if("UnityFS".equals(c.kind))ext=".bundle"; else if("NKDB".equals(c.kind))ext=".nkdb"; else if("ZIP".equals(c.kind))ext=".zip";
                            Uri out=createDoc(tree,String.format(Locale.US,"%06d_%s_%s%s",c.e.index,c.kind,c.e.hashHex(),ext),"application/octet-stream");
                            if(out==null){failed++;continue;}
                            try(OutputStream os=getContentResolver().openOutputStream(out,"w")){copyRange(ch,c.e.offset,c.e.size,os);} blobs++;
                        }catch(Exception x){failed++;}
                    }
                }
                json.append("  ]\n}\n");

                Uri csvUri=createDoc(tree,"nikke_localization_candidates.csv","text/csv");
                if(csvUri!=null)try(OutputStream os=getContentResolver().openOutputStream(csvUri,"w")){os.write(csv.toString().getBytes(StandardCharsets.UTF_8));}
                Uri jsonUri=createDoc(tree,"nikke_localization_candidates.json","application/json");
                if(jsonUri!=null)try(OutputStream os=getContentResolver().openOutputStream(jsonUri,"w")){os.write(json.toString().getBytes(StandardCharsets.UTF_8));}

                // Font report + direct extraction of validated embedded TTF/OTF/WOFF files.
                StringBuilder fcsv=new StringBuilder("block_index,block_kind,block_offset,block_size,hash,keywords,font_type,font_relative_offset,font_absolute_offset,font_length,preview\n");
                StringBuilder fjson=new StringBuilder();
                fjson.append("{\n  \"format\": \"NIKKE font candidate scan\",\n  \"candidate_count\": ").append(fontCandidates.size()).append(",\n  \"candidates\": [\n");
                int extractedFonts=0;
                Uri fontsDir=createDir(tree,"nikke_fonts");
                for(int i=0;i<fontCandidates.size();i++){
                    FontCandidate fc=fontCandidates.get(i); String kw=join(fc.result.terms,"|");
                    fjson.append("    {\n      \"block_index\": ").append(fc.e.index).append(",\n")
                            .append("      \"block_kind\": \"").append(jsonEscape(fc.kind)).append("\",\n")
                            .append("      \"block_offset\": ").append(fc.e.offset).append(",\n")
                            .append("      \"block_size\": ").append(fc.e.size).append(",\n")
                            .append("      \"hash\": \"").append(fc.e.hashHex()).append("\",\n")
                            .append("      \"keywords\": \"").append(jsonEscape(kw)).append("\",\n")
                            .append("      \"preview\": \"").append(jsonEscape(fc.result.preview)).append("\",\n")
                            .append("      \"fonts\": [");
                    if(fc.result.embeddedFonts.isEmpty()){
                        fcsv.append(fc.e.index).append(',').append(csvQ(fc.kind)).append(',').append(fc.e.offset).append(',').append(fc.e.size).append(',').append(fc.e.hashHex()).append(',').append(csvQ(kw)).append(",,,,,").append(csvQ(fc.result.preview)).append('\n');
                    }
                    for(int j=0;j<fc.result.embeddedFonts.size();j++){
                        FontScanner.EmbeddedFont ef=fc.result.embeddedFonts.get(j);
                        if(j>0)fjson.append(',');
                        fjson.append("{\"type\":\"").append(jsonEscape(ef.type)).append("\",\"relative_offset\":").append(ef.relativeOffset).append(",\"absolute_offset\":").append(fc.e.offset+ef.relativeOffset).append(",\"length\":").append(ef.length).append('}');
                        fcsv.append(fc.e.index).append(',').append(csvQ(fc.kind)).append(',').append(fc.e.offset).append(',').append(fc.e.size).append(',').append(fc.e.hashHex()).append(',').append(csvQ(kw)).append(',').append(csvQ(ef.type)).append(',').append(ef.relativeOffset).append(',').append(fc.e.offset+ef.relativeOffset).append(',').append(ef.length).append(',').append(csvQ(fc.result.preview)).append('\n');
                        if(fontsDir!=null){
                            String ext="."+ef.type.toLowerCase(Locale.ROOT);
                            Uri fo=createDocIn(fontsDir,String.format(Locale.US,"font_b%06d_o%d_%s%s",fc.e.index,ef.relativeOffset,fc.e.hashHex(),ext),"application/octet-stream");
                            if(fo!=null)try(OutputStream os=getContentResolver().openOutputStream(fo,"w")){copyRange(ch,fc.e.offset+ef.relativeOffset,ef.length,os);extractedFonts++;}
                        }
                    }
                    fjson.append("]\n    }"); if(i+1<fontCandidates.size())fjson.append(','); fjson.append('\n');
                }
                fjson.append("  ]\n}\n");
                Uri fcsvUri=createDoc(tree,"nikke_font_candidates.csv","text/csv");
                if(fcsvUri!=null)try(OutputStream os=getContentResolver().openOutputStream(fcsvUri,"w")){os.write(fcsv.toString().getBytes(StandardCharsets.UTF_8));}
                Uri fjsonUri=createDoc(tree,"nikke_font_candidates.json","application/json");
                if(fjsonUri!=null)try(OutputStream os=getContentResolver().openOutputStream(fjsonUri,"w")){os.write(fjson.toString().getBytes(StandardCharsets.UTF_8));}

                final int d=blobs,f=failed, xf=extractedFonts;
                runOnUiThread(()->{status.append("\nExport hotov. Lokalizační JSON/CSV + fontový JSON/CSV vytvořeny. Malých bloků: "+d+", vyříznutých fontů: "+xf+", chyby bloků: "+f+".");exportButton.setEnabled(true);});
            }catch(Exception ex){runOnUiThread(()->{status.append("\nChyba exportu: "+ex);exportButton.setEnabled(true);});}
        }).start();
    }

    private Uri createDir(Uri tree,String name){
        try{
            String treeId=android.provider.DocumentsContract.getTreeDocumentId(tree);
            Uri parent=android.provider.DocumentsContract.buildDocumentUriUsingTree(tree,treeId);
            return android.provider.DocumentsContract.createDocument(getContentResolver(),parent,android.provider.DocumentsContract.Document.MIME_TYPE_DIR,name);
        }catch(Exception e){return null;}
    }
    private Uri createDocIn(Uri parent,String name,String mime){
        try{return android.provider.DocumentsContract.createDocument(getContentResolver(),parent,mime,name);}catch(Exception e){return null;}
    }

    private Uri createDoc(Uri tree,String name,String mime){
        try{
            String treeId=android.provider.DocumentsContract.getTreeDocumentId(tree);
            Uri parent=android.provider.DocumentsContract.buildDocumentUriUsingTree(tree,treeId);
            return android.provider.DocumentsContract.createDocument(getContentResolver(),parent,mime,name);
        }catch(Exception e){return null;}
    }
    private void copyRange(FileChannel ch,long off,long size,OutputStream os)throws IOException{ByteBuffer b=ByteBuffer.allocate(1024*1024);long pos=off,left=size;while(left>0){b.clear();b.limit((int)Math.min(b.capacity(),left));int r=ch.read(b,pos);if(r<0)throw new EOFException();if(r==0)continue;os.write(b.array(),0,r);pos+=r;left-=r;}}
    private String human(long n){String[]u={"B","KB","MB","GB"};double d=n;int i=0;while(d>=1024&&i<u.length-1){d/=1024;i++;}return new DecimalFormat("0.##").format(d)+" "+u[i];}
    private String join(Collection<String> xs,String sep){StringBuilder s=new StringBuilder();for(String x:xs){if(s.length()>0)s.append(sep);s.append(x);}return s.toString();}
    private String shorten(String s,int n){return s.length()<=n?s:s.substring(0,n)+"…";}
    private String csvQ(String s){return "\""+(s==null?"":s.replace("\"","\"\"").replace("\r"," ").replace("\n"," "))+"\"";}
    private String jsonEscape(String s){
        if(s==null)return ""; StringBuilder o=new StringBuilder();
        for(int i=0;i<s.length();i++){
            char c=s.charAt(i);
            switch(c){case '\\':o.append("\\\\");break;case '"':o.append("\\\"");break;case '\n':o.append("\\n");break;case '\r':o.append("\\r");break;case '\t':o.append("\\t");break;default:if(c<32)o.append(String.format(Locale.US,"\\u%04x",(int)c));else o.append(c);}
        }
        return o.toString();
    }
}
