package online.hrycesky.nikketoolkit;

import java.io.*;
import java.nio.*;
import java.nio.channels.FileChannel;
import java.util.*;

public final class CidxParser {
    public static final class Entry {
        public final long offset;
        public final long size;
        public final byte[] hash;
        public final int index;
        Entry(int index, long offset, long size, byte[] hash) {
            this.index=index; this.offset=offset; this.size=size; this.hash=hash;
        }
        public String hashHex() {
            StringBuilder sb=new StringBuilder();
            for(byte b: hash) sb.append(String.format(Locale.US, "%02x", b & 0xff));
            return sb.toString();
        }
    }

    public static List<Entry> parse(FileChannel ch) throws IOException {
        ByteBuffer h=ByteBuffer.allocate(28).order(ByteOrder.LITTLE_ENDIAN);
        readFully(ch,h,0); h.flip();
        byte[] magic=new byte[4]; h.get(magic);
        if(!(magic[0]=='C'&&magic[1]=='I'&&magic[2]=='D'&&magic[3]=='X'))
            throw new IOException("Soubor nemá hlavičku CIDX.");
        int version=h.getInt();
        int count=h.getInt();
        h.position(28);
        if(version != 1) throw new IOException("Nepodporovaná CIDX verze: "+version);
        if(count < 0 || count > 2_000_000) throw new IOException("Neplatný počet záznamů: "+count);

        List<Entry> out=new ArrayList<>(count);
        ByteBuffer rec=ByteBuffer.allocate(28).order(ByteOrder.LITTLE_ENDIAN);
        long pos=28;
        for(int i=0;i<count;i++) {
            rec.clear(); readFully(ch,rec,pos); rec.flip();
            long off=rec.getLong();
            long size=Integer.toUnsignedLong(rec.getInt());
            byte[] hash=new byte[16]; rec.get(hash);
            out.add(new Entry(i,off,size,hash));
            pos += 28;
        }
        return out;
    }

    private static void readFully(FileChannel ch, ByteBuffer b, long pos) throws IOException {
        int n=0;
        while(b.hasRemaining()) {
            int r=ch.read(b,pos+n);
            if(r<0) throw new EOFException();
            n+=r;
        }
    }
}
