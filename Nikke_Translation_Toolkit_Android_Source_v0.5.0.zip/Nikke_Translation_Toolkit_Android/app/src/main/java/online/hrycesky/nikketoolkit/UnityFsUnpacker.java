package online.hrycesky.nikketoolkit;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Minimal UnityFS reader sufficient for decompressing block-info and LZ4/LZMA data blocks. */
public final class UnityFsUnpacker {
    private UnityFsUnpacker() {}

    public static final class Result {
        public final byte[] data;
        public final List<String> paths;
        public final String summary;
        public final int blockCount;

        Result(byte[] data, List<String> paths, String summary, int blockCount) {
            this.data = data;
            this.paths = paths;
            this.summary = summary;
            this.blockCount = blockCount;
        }
    }

    private static final class Block {
        int unpacked, packed, flags;
        Block(int unpacked, int packed, int flags) { this.unpacked=unpacked; this.packed=packed; this.flags=flags; }
    }

    public static boolean isUnityFs(byte[] b) {
        return starts(b, 0, "UnityFS\0".getBytes(StandardCharsets.US_ASCII));
    }

    public static Result unpack(byte[] input) throws IOException {
        if (!isUnityFs(input)) throw new IOException("Není UnityFS");
        BEReader r = new BEReader(input);
        String sig = r.cString();
        int format = r.i32();
        String unityVersion = r.cString();
        String unityRevision = r.cString();
        long bundleSize = r.i64();
        int compInfoSize = r.i32();
        int uncompInfoSize = r.i32();
        int flags = r.i32();

        if (!"UnityFS".equals(sig)) throw new IOException("Neočekávaná Unity signatura: " + sig);
        if (compInfoSize < 0 || uncompInfoSize < 0 || compInfoSize > input.length)
            throw new IOException("Neplatné UnityFS block-info velikosti");
        if (uncompInfoSize > DeepContainerScanner.MAX_DECOMPRESSED_BYTES)
            throw new IOException("UnityFS block-info je příliš velké");

        if (format >= 7) r.align(16);
        int dataStartBase = r.pos;
        boolean infoAtEnd = (flags & 0x80) != 0;
        byte[] packedInfo;
        int dataPos;
        if (infoAtEnd) {
            int infoPos = input.length - compInfoSize;
            if (infoPos < dataStartBase) throw new IOException("UnityFS block-info offset je mimo soubor");
            packedInfo = Arrays.copyOfRange(input, infoPos, infoPos + compInfoSize);
            dataPos = dataStartBase;
        } else {
            if (r.pos + compInfoSize > input.length) throw new IOException("UnityFS block-info přesahuje soubor");
            packedInfo = r.bytes(compInfoSize);
            dataPos = r.pos;
        }
        if ((flags & 0x200) != 0) dataPos = align(dataPos, 16);

        byte[] info = decompress(packedInfo, uncompInfoSize, flags & 0x3f);
        BEReader ir = new BEReader(info);
        ir.skip(16); // uncompressed data hash
        int count = ir.i32();
        if (count < 0 || count > 1_000_000) throw new IOException("Neplatný počet UnityFS bloků: " + count);
        List<Block> blocks = new ArrayList<>(count);
        long totalUnpacked = 0;
        StringBuilder compSummary = new StringBuilder();
        for (int i=0;i<count;i++) {
            int u = ir.i32();
            int c = ir.i32();
            int f = ir.u16();
            if (u < 0 || c < 0) throw new IOException("Neplatná velikost UnityFS bloku");
            totalUnpacked += (long)u;
            if (totalUnpacked > DeepContainerScanner.MAX_DECOMPRESSED_BYTES)
                throw new IOException("UnityFS rozbalená data přesahují limit");
            blocks.add(new Block(u,c,f));
            if (i < 12) {
                if (compSummary.length()>0) compSummary.append(',');
                compSummary.append(compressionName(f & 0x3f));
            }
        }

        int nodeCount = ir.i32();
        if (nodeCount < 0 || nodeCount > 1_000_000) throw new IOException("Neplatný počet UnityFS souborů: " + nodeCount);
        List<String> paths = new ArrayList<>(Math.min(nodeCount, 10000));
        for (int i=0;i<nodeCount;i++) {
            ir.i64(); // offset
            ir.i64(); // size
            ir.i32(); // flags
            String path = ir.cString();
            if (paths.size() < 10000) paths.add(path);
        }

        ByteArrayOutputStream out = new ByteArrayOutputStream((int)Math.min(totalUnpacked, 8L*1024*1024));
        int p = dataPos;
        for (Block b : blocks) {
            if (p < 0 || p + b.packed > input.length) throw new IOException("UnityFS datový blok přesahuje soubor");
            byte[] packed = Arrays.copyOfRange(input, p, p + b.packed);
            byte[] unpacked = decompress(packed, b.unpacked, b.flags & 0x3f);
            out.write(unpacked);
            p += b.packed;
        }

        return new Result(out.toByteArray(), paths,
                "UnityFS format="+format+", Unity="+unityVersion+", revision="+unityRevision+
                        ", blocks="+count+", files="+nodeCount+", compression="+compSummary+
                        ", declaredSize="+bundleSize,
                count);
    }

    private static byte[] decompress(byte[] packed, int expected, int type) throws IOException {
        switch(type) {
            case 0:
                if (expected == packed.length) return packed;
                return Arrays.copyOf(packed, Math.min(packed.length, expected));
            case 1: return CompressionUtils.lzmaUnity(packed, expected);
            case 2:
            case 3: return CompressionUtils.lz4Block(packed, expected);
            default: throw new IOException("Nepodporovaná UnityFS komprese: " + type);
        }
    }

    private static String compressionName(int type) {
        switch(type){case 0:return "none";case 1:return "LZMA";case 2:return "LZ4";case 3:return "LZ4HC";default:return "type"+type;}
    }

    private static int align(int p, int n){ return (p + n - 1) & ~(n - 1); }
    private static boolean starts(byte[] b,int off,byte[] x){ if(off<0||off+x.length>b.length)return false; for(int i=0;i<x.length;i++)if(b[off+i]!=x[i])return false; return true; }

    private static final class BEReader {
        final byte[] b; int pos;
        BEReader(byte[] b){this.b=b;}
        void need(int n)throws IOException{ if(n<0||pos+n>b.length)throw new EOFException("UnityFS: neočekávaný konec dat"); }
        void skip(int n)throws IOException{need(n);pos+=n;}
        void align(int n){pos=UnityFsUnpacker.align(pos,n);}
        int u8()throws IOException{need(1);return b[pos++]&255;}
        int u16()throws IOException{return (u8()<<8)|u8();}
        int i32()throws IOException{need(4);int v=((b[pos]&255)<<24)|((b[pos+1]&255)<<16)|((b[pos+2]&255)<<8)|(b[pos+3]&255);pos+=4;return v;}
        long i64()throws IOException{long hi=i32()&0xffffffffL,lo=i32()&0xffffffffL;return (hi<<32)|lo;}
        byte[] bytes(int n)throws IOException{need(n);byte[] x=Arrays.copyOfRange(b,pos,pos+n);pos+=n;return x;}
        String cString()throws IOException{int s=pos;while(pos<b.length&&b[pos]!=0)pos++;if(pos>=b.length)throw new EOFException("UnityFS: neukončený řetězec");String x=new String(b,s,pos-s,StandardCharsets.UTF_8);pos++;return x;}
    }
}
