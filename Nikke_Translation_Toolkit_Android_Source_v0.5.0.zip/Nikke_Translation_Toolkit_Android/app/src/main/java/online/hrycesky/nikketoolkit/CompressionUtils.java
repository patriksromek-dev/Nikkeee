package online.hrycesky.nikketoolkit;

import net.jpountz.lz4.LZ4Factory;
import net.jpountz.lz4.LZ4FrameInputStream;
import org.tukaani.xz.LZMAInputStream;

import java.io.*;
import java.util.Arrays;

/** Compression helpers used by the deep scanner. */
public final class CompressionUtils {
    private CompressionUtils() {}

    public static byte[] lz4Block(byte[] src, int expectedSize) throws IOException {
        if (expectedSize < 0 || expectedSize > DeepContainerScanner.MAX_DECOMPRESSED_BYTES)
            throw new IOException("LZ4 výstup je příliš velký: " + expectedSize);
        byte[] out = new byte[expectedSize];
        try {
            int n = LZ4Factory.fastestInstance().safeDecompressor()
                    .decompress(src, 0, src.length, out, 0, expectedSize);
            if (n == expectedSize) return out;
            return Arrays.copyOf(out, n);
        } catch (RuntimeException ex) {
            throw new IOException("LZ4 blok nelze rozbalit", ex);
        }
    }

    /** Unity stores LZMA blocks as 5 bytes of properties/dictionary followed by a raw LZMA1 stream. */
    public static byte[] lzmaUnity(byte[] src, int expectedSize) throws IOException {
        if (src.length < 6) throw new IOException("LZMA blok je příliš krátký");
        if (expectedSize < 0 || expectedSize > DeepContainerScanner.MAX_DECOMPRESSED_BYTES)
            throw new IOException("LZMA výstup je příliš velký: " + expectedSize);

        byte props = src[0];
        int dictSize = (src[1] & 0xff) | ((src[2] & 0xff) << 8) | ((src[3] & 0xff) << 16) | ((src[4] & 0xff) << 24);
        if (dictSize < 0) dictSize = Math.max(4096, Math.min(expectedSize, 64 * 1024 * 1024));
        ByteArrayInputStream bin = new ByteArrayInputStream(src, 5, src.length - 5);
        try (LZMAInputStream in = new LZMAInputStream(bin, (long) expectedSize, props, dictSize)) {
            return readExactOrLess(in, expectedSize);
        } catch (IOException rawFail) {
            // Some external data uses the normal .lzma "alone" header. Try that as a fallback.
            try (LZMAInputStream in = new LZMAInputStream(new ByteArrayInputStream(src))) {
                return readLimited(in, DeepContainerScanner.MAX_DECOMPRESSED_BYTES);
            } catch (IOException aloneFail) {
                aloneFail.addSuppressed(rawFail);
                throw aloneFail;
            }
        }
    }

    public static byte[] lz4Frame(byte[] src) throws IOException {
        try (LZ4FrameInputStream in = new LZ4FrameInputStream(new ByteArrayInputStream(src))) {
            return readLimited(in, DeepContainerScanner.MAX_DECOMPRESSED_BYTES);
        }
    }

    public static byte[] lzmaAlone(byte[] src) throws IOException {
        try (LZMAInputStream in = new LZMAInputStream(new ByteArrayInputStream(src))) {
            return readLimited(in, DeepContainerScanner.MAX_DECOMPRESSED_BYTES);
        }
    }

    private static byte[] readExactOrLess(InputStream in, int expected) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream(Math.min(expected, 1024 * 1024));
        byte[] buf = new byte[64 * 1024];
        int total = 0;
        while (true) {
            int n = in.read(buf);
            if (n < 0) break;
            total += n;
            if (total > DeepContainerScanner.MAX_DECOMPRESSED_BYTES)
                throw new IOException("Rozbalená data překročila bezpečnostní limit");
            out.write(buf, 0, n);
        }
        return out.toByteArray();
    }

    private static byte[] readLimited(InputStream in, int limit) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream(256 * 1024);
        byte[] buf = new byte[64 * 1024];
        int total = 0;
        while (true) {
            int n = in.read(buf);
            if (n < 0) break;
            total += n;
            if (total > limit) throw new IOException("Rozbalená data překročila limit " + limit + " B");
            out.write(buf, 0, n);
        }
        return out.toByteArray();
    }
}
