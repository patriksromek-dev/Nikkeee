package online.hrycesky.nikketoolkit;

import java.io.*;
import java.nio.*;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Detects compressed/container layers and exposes decompressed bytes for a second localization scan. */
public final class DeepContainerScanner {
    public static final int MAX_ENTRY_BYTES = 64 * 1024 * 1024;
    public static final int MAX_DECOMPRESSED_BYTES = 256 * 1024 * 1024;
    private static final byte[] UNITY = "UnityFS\0".getBytes(StandardCharsets.US_ASCII);

    public static final class Payload {
        public final String layer;
        public final String detail;
        public final byte[] data;
        public final List<String> paths;
        Payload(String layer,String detail,byte[] data,List<String>paths){this.layer=layer;this.detail=detail;this.data=data;this.paths=paths;}
    }

    private DeepContainerScanner() {}

    public static boolean likelyContainer(byte[] head) {
        return starts(head, UNITY) || isLz4Frame(head) || looksLzmaAlone(head) || starts(head, "NKAB".getBytes(StandardCharsets.US_ASCII));
    }

    public static List<Payload> unpack(FileChannel ch,long offset,long size) {
        List<Payload> out=new ArrayList<>();
        if(size<=0 || size>MAX_ENTRY_BYTES) return out;
        try {
            byte[] raw=readRange(ch,offset,(int)size);
            // NIKKE wrapper support already existed in the project; if decryption succeeds, inspect its result too.
            if(starts(raw,"NKAB".getBytes(StandardCharsets.US_ASCII))){
                try{
                    byte[] dec=NkabDecryptor.decrypt(raw);
                    addRecognized(out,dec,"NKAB→");
                }catch(Exception ignored){}
            }
            addRecognized(out,raw,"");
        } catch(Exception ignored) {}
        return out;
    }

    private static void addRecognized(List<Payload> out,byte[] data,String prefix) throws IOException {
        if(UnityFsUnpacker.isUnityFs(data)){
            UnityFsUnpacker.Result r=UnityFsUnpacker.unpack(data);
            out.add(new Payload(prefix+"UnityFS",r.summary,r.data,r.paths));
            // One cheap nested pass: occasionally a virtual file itself starts with another UnityFS.
            int nested=find(data,UNITY,1,Math.min(data.length,1024*1024));
            if(nested>0 && nested < data.length-16){
                try{
                    byte[] sub=Arrays.copyOfRange(data,nested,data.length);
                    UnityFsUnpacker.Result nr=UnityFsUnpacker.unpack(sub);
                    out.add(new Payload(prefix+"Nested UnityFS",nr.summary,nr.data,nr.paths));
                }catch(Exception ignored){}
            }
            return;
        }
        if(isLz4Frame(data)){
            byte[] dec=CompressionUtils.lz4Frame(data);
            out.add(new Payload(prefix+"LZ4 frame","raw LZ4 frame",dec,Collections.<String>emptyList()));
            if(UnityFsUnpacker.isUnityFs(dec)){
                UnityFsUnpacker.Result r=UnityFsUnpacker.unpack(dec);
                out.add(new Payload(prefix+"LZ4→UnityFS",r.summary,r.data,r.paths));
            }
            return;
        }
        if(looksLzmaAlone(data)){
            try{
                byte[] dec=CompressionUtils.lzmaAlone(data);
                out.add(new Payload(prefix+"LZMA","LZMA-alone stream",dec,Collections.<String>emptyList()));
                if(UnityFsUnpacker.isUnityFs(dec)){
                    UnityFsUnpacker.Result r=UnityFsUnpacker.unpack(dec);
                    out.add(new Payload(prefix+"LZMA→UnityFS",r.summary,r.data,r.paths));
                }
            }catch(Exception ignored){}
        }
    }

    public static byte[] readHead(FileChannel ch,long off,long size,int max)throws IOException{
        int want=(int)Math.min((long)max,size); ByteBuffer b=ByteBuffer.allocate(want); int got=0;
        while(b.hasRemaining()){int r=ch.read(b,off+got);if(r<0||r==0)break;got+=r;}
        byte[] out=new byte[got];b.flip();b.get(out);return out;
    }

    private static byte[] readRange(FileChannel ch,long off,int len)throws IOException{
        ByteBuffer b=ByteBuffer.allocate(len);int got=0;
        while(b.hasRemaining()){int r=ch.read(b,off+got);if(r<0)break;if(r==0)break;got+=r;}
        byte[] out=new byte[got];b.flip();b.get(out);return out;
    }

    private static boolean isLz4Frame(byte[] b){return b.length>=4&&(b[0]&255)==0x04&&(b[1]&255)==0x22&&(b[2]&255)==0x4d&&(b[3]&255)==0x18;}

    private static boolean looksLzmaAlone(byte[] b){
        if(b.length<13)return false;
        int props=b[0]&255;if(props>224)return false;
        int dict=(b[1]&255)|((b[2]&255)<<8)|((b[3]&255)<<16)|((b[4]&255)<<24);
        boolean dictOk=dict==0xFFFFFFFF || (dict>=4096 && (dict&(dict-1))==0) || (dict>=4096 && dict<=64*1024*1024);
        if(!dictOk)return false;
        long size=0;for(int i=0;i<8;i++)size|=((long)b[5+i]&255L)<<(8*i);
        return size==-1L || size==0xffffffffffffffffL || (size>=0 && size<=MAX_DECOMPRESSED_BYTES);
    }

    private static boolean starts(byte[] b,byte[] x){if(b.length<x.length)return false;for(int i=0;i<x.length;i++)if(b[i]!=x[i])return false;return true;}
    private static int find(byte[] b,byte[] x,int from,int to){outer:for(int i=Math.max(0,from);i<=Math.min(to,b.length)-x.length;i++){for(int j=0;j<x.length;j++)if(b[i+j]!=x[j])continue outer;return i;}return -1;}
}
